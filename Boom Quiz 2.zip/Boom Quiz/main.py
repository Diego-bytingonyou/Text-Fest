import flet as ft

import time

def main(page: ft.Page): 
    page.bgcolor = "#ffffff"
    
    questions = [
        {"question": "How many elements are in the periodic table?\nA. 115\nB. 118", "answer": "B"},
        {"question": "Which is the capital city of Canada?\nA. Toronto\nB. Ottawa", "answer": "B"},
        {"question": "What is Africa?\nA. A continent\nB. A country", "answer": "A"},
        {"question": "Which is best?\nA. Max\nB. Prime\nC. Netflix\nD. Youtube", "answer": "C"},
        {"question": "What do most people grow up with, cable or dvd?\nA. Cable\nB. DVD", "answer": "A"},
        {"question": " Would you  buy the Nintendo Switch 2?\nA. Yes\nB. No", "answer": "B"},
        {"question": "How much is a Benjamin?\nA. Ten Dollars\nB. Hundred Dollars\nC. Hundred Pesos", "answer": "B"},
        {"question": "What is 10+9?\nA. 21\nB. 19", "answer": "B"},
        {"question": "What is the best holiday of the year?\nA. Thanksgiving\nB. Halloween\nC. Christmas\nD. Easter\nE. Saint Patrick’s Day\nF. Valentine’s Day", "answer": "C"},
        {"question": "Did you enjoy this game?\nA. Yes\nB. No", "answer": "A"},
    ]
    cq = 0
    cv = 30
    running = True

    kaboom = ft.Audio(src="/Users/davidfeliz/Desktop/Boom Quiz/Audio/Ka-Boom.mp3", autoplay=False)
    page.add(kaboom)
    explosion = ft.Audio(src="/Users/davidfeliz/Desktop/Boom Quiz/Audio/Explosion.mp3", autoplay=False)
    page.add(explosion)
    success = ft.Audio(src="/Users/davidfeliz/Desktop/Boom Quiz/Audio/Success.mp3", autoplay=False)
    page.add(success)
    right = ft.Audio(src="/Users/davidfeliz/Desktop/Boom Quiz/Audio/Right.mp3", autoplay=False)
    page.add(right)
    wrong = ft.Audio(src="/Users/davidfeliz/Desktop/Boom Quiz/Audio/Wrong.mp3", autoplay=False)
    page.add(wrong)
    ppp = ft.Audio(src="/Users/davidfeliz/Desktop/Boom Quiz/Audio/ticking.mp3", autoplay=True)
    page.add(ppp)
    
    #ticking
    #Pixel Peeker Polka

    def kaboom_audio():
        kaboom.play()
    def explosion_audio():
        explosion.play()
    def success_audio():
        success.play()
    def right_audio():
        right.play()   
    def wrong_audio():
        wrong.play()
    
    def ppp_audio():
        ppp.play()

        ppp_audio()


    bom1 = ft.Image(src="bomb1.png", visible=True, width=800, height=100)
    page.add(bom1)
    boom = ft.Image(src="boom.png", visible=False, width=1200, height=200)
    bomdef = ft.Image(src="bomb_defused.png", visible=False, width=800, height=100)

    countdown = ft.Text(value=cv, color="#121212", size=20)
    q = ft.Text(value=questions[cq]["question"], color="#121212", size=15)
    t = ft.TextField(label="Answer", color="#121212")
    f = ft.Text(value="Game Over", color="#121212", visible=False)

    page.add(countdown)
    page.add(f)

    def update_question():
        nonlocal cq, running, bomdef
        if cq < len(questions):
            q.value = questions[cq]["question"]
        else:
            q.value = "You won!"
            t.visible = False
            c.visible = False
            bom1.visible = False
            bomdef.visible = True
            success_audio()
            ppp.pause()
            running = False
        page.update()


    def update_bomb(cv):
        if cv >= 25:
            bom1.src = "bomb2.png"
        elif cv >= 20:
            bom1.src = "bomb3.png"
        elif cv >= 15:
            bom1.src = "bomb4.png"
        elif cv >= 10:
            bom1.src = "bomb5.png"
        elif cv >= 5:
            bom1.src = "bomb6.png"
        elif cv >= 3:
            bom1.src = "bomb7.png"
        page.update()

    def correct():
        nonlocal cv
        cv += 10
        countdown.value = str(cv)
        right_audio()
        update_bomb(cv)
        page.update()

    def incorrect():
        nonlocal cv
        cv -= 10
        countdown.value = str(cv)
        wrong_audio()
        update_bomb(cv)
        page.update()

    def check(e):
        nonlocal cq
        if cq < len(questions):
            if t.value.strip().upper() == questions[cq]["answer"]:
                correct()
            else:
                incorrect()
            cq += 1
            t.value = ""
            update_question()

    c = ft.ElevatedButton("Check", on_click=check, color="#ffffff")

    def count():
        nonlocal cv, running
        while cv > 0 and running:
            time.sleep(1)
            cv -= 1
            countdown.value = str(cv)
            update_bomb(cv)
            page.update()
        if cv <= 0:
            f.visible = True
            q.visible = False
            t.visible = False
            c.visible = False
            bom1.visible = False
            boom.visible = True
            kaboom_audio()
            explosion_audio()
            ppp.pause()
            update_bomb(cv)
            page.update()

    
    page.add(bomdef)
    page.add(q)
    page.add(t)
    page.add(c)
    page.add(boom)
    page.add(f)

    count()

ft.app(target=main, assets_dir="boom")